#include <stdio.h>

void get_flag()
{
	puts("BOOM");
}
