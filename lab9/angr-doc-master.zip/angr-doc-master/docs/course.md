# How to angr

This is a stub for a step-by-step angr course.
This course is meant to supplement the examples, gitbook, and API reference by gradually introducing new users to more and more advanced angr features.

Where possible, we'll include slides explaining the underlying concepts and maybe even some video tutorials!

# TODO: basic symbolic execution - step a path group

# TODO: next steps - using avoid, etc to cut down on path explosion

# TODO: next steps - veritesting?

# TODO: next steps - custom hooks to replace binary code and make things easier for angr

# TODO: let's start on some static analysis (CFG example to target symbolic execution?)

# TODO: VFG, DDG, something?

# TODO: under-constrained symbolic execution based on VFG results?

# more advanced stuff!
